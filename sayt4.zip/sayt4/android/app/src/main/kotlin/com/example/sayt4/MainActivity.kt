package com.example.sayt4

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
