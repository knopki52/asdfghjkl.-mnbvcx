import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: CourseScreen(),
    );
  }
}

Color purpleColor = const Color(0xFF5B4FE5);
Color lightPurple = const Color(0xFFEDEBFC);
Color grayText = const Color(0xFF8A8A8A);

class CourseScreen extends StatelessWidget {
  const CourseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: ListView(
            children: [
              topBar(),
              const SizedBox(height: 20),
              heroImage(),
              const SizedBox(height: 16),
              chipsRow(),
              const SizedBox(height: 20),
              const Text(
                '3D Design Basic',
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 12),
              Text(
                'In this course you will learn how to build a space to a 3-dimensional product. There are 24 premium learning videos for you.',
                style: TextStyle(fontSize: 15, color: grayText, height: 1.4),
              ),
              const SizedBox(height: 20),
              lessonsHeader(),
              const SizedBox(height: 14),
              lessonItem(),
              const SizedBox(height: 24),
              enrollButton(),
            ],
          ),
        ),
      ),
    );
  }
}

Widget topBar() {
  return Row(
    children: [
      Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: lightPurple,
          borderRadius: BorderRadius.circular(14),
        ),
        alignment: Alignment.center,
        child: Icon(Icons.arrow_back_ios_new, color: purpleColor, size: 18),
      ),
      const SizedBox(width: 16),
      const Text(
        '3D Design Basic',
        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800),
      ),
    ],
  );
}

Widget heroImage() {
  return Container(
    height: 230,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(20),
      gradient: const LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF1B1F6B), Color(0xFF5B4FE5), Color(0xFF8A7CF0)],
      ),
    ),
  );
}

Widget chipsRow() {
  return Row(
    children: [
      chip(icon: Icons.public, text: '4.569'),
      const SizedBox(width: 10),
      chip(icon: Icons.star, text: '4.9'),
      const SizedBox(width: 10),
      filledChip(text: 'Best Seller'),
    ],
  );
}

Widget chip({required IconData icon, required String text}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: lightPurple,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: [
        Icon(icon, size: 16, color: purpleColor),
        const SizedBox(width: 6),
        Text(text, style: TextStyle(color: purpleColor, fontWeight: FontWeight.w600)),
      ],
    ),
  );
}

Widget filledChip({required String text}) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    decoration: BoxDecoration(
      color: purpleColor,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
  );
}

Widget lessonsHeader() {
  return Row(
    mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      const Text(
        '24 Lessons (20 hours)',
        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
      ),
      Text('See all', style: TextStyle(color: purpleColor, fontWeight: FontWeight.w600)),
    ],
  );
}

Widget lessonItem() {
  return Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(18),
      boxShadow: [
        BoxShadow(color: Colors.black.withValues(alpha: 0.06), blurRadius: 12),
      ],
    ),
    child: Row(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0xFF3B2F8F), Color(0xFF8A7CF0)],
            ),
          ),
        ),
        const SizedBox(width: 14),
        const Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Introduction to 3D',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              SizedBox(height: 4),
              Text('20 mins', style: TextStyle(fontSize: 13, color: Colors.grey)),
            ],
          ),
        ),
        Icon(Icons.check_circle, color: purpleColor),
      ],
    ),
  );
}

Widget enrollButton() {
  return Container(
    width: double.infinity,
    height: 56,
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(28),
      gradient: LinearGradient(
        colors: [purpleColor, const Color(0xFF8A7CF0)],
      ),
    ),
    alignment: Alignment.center,
    child: const Text(
      'Enroll - \$24.99',
      style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: Colors.white),
    ),
  );
}
