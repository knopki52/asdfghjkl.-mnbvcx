package com.example.medinow_design

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
