import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MedinowScreen(),
    );
  }
}

const backgroundColor = Color(0xFF4A9691);
const mintColor = Color(0xFFD6EEF0);
const badgeColor = Color(0xFF4A2E22);
const matColor = Color(0xFF356E6A);
const figureColor = Color(0xFF223238);

class MedinowScreen extends StatelessWidget {
  const MedinowScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: backgroundColor,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            children: [
              const SizedBox(height: 28),
              const Text(
                'medinow',
                style: TextStyle(
                  fontSize: 34,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 6),
              const Text(
                'Meditate With Us!',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 48),
              pillButton(
                text: 'Sign in with Apple',
                background: Colors.white,
                textColor: Colors.black,
                icon: Icons.apple,
              ),
              const SizedBox(height: 14),
              pillButton(
                text: 'Continue with Email or Phone',
                background: mintColor,
                textColor: Colors.black87,
              ),
              const SizedBox(height: 18),
              const Text(
                'Continue With Google',
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
              ),
              const Spacer(),
              illustration(),
              const SizedBox(height: 12),
            ],
          ),
        ),
      ),
    );
  }
}

Widget pillButton({
  required String text,
  required Color background,
  required Color textColor,
  IconData? icon,
}) {
  return Container(
    width: double.infinity,
    height: 54,
    decoration: BoxDecoration(
      color: background,
      borderRadius: BorderRadius.circular(27),
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        if (icon != null) ...[
          Icon(icon, size: 20, color: textColor),
          const SizedBox(width: 8),
        ],
        Text(
          text,
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: textColor,
          ),
        ),
      ],
    ),
  );
}

Widget illustration() {
  return SizedBox(
    height: 220,
    width: double.infinity,
    child: Stack(
      alignment: Alignment.bottomCenter,
      children: [
        const Positioned(
          left: 0,
          bottom: 30,
          child: Icon(Icons.eco, size: 64, color: Colors.white24),
        ),
        const Positioned(
          right: 4,
          bottom: 60,
          child: Icon(Icons.eco, size: 48, color: Colors.white24),
        ),
        const Positioned(
          right: 40,
          bottom: 10,
          child: Icon(Icons.spa, size: 40, color: Colors.white24),
        ),
        Positioned(
          bottom: 8,
          child: Transform.rotate(
            angle: 0.785398,
            child: Container(
              width: 120,
              height: 120,
              decoration: BoxDecoration(
                color: matColor,
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ),
        ),
        const Positioned(
          bottom: 24,
          child: Icon(Icons.self_improvement, size: 150, color: figureColor),
        ),
        Positioned(
          top: 4,
          right: 90,
          child: Container(
            width: 34,
            height: 34,
            decoration: const BoxDecoration(
              color: badgeColor,
              shape: BoxShape.circle,
            ),
            alignment: Alignment.center,
            child: const Icon(Icons.self_improvement, size: 18, color: Colors.white),
          ),
        ),
      ],
    ),
  );
}
