package com.example.sayt3

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
