import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: PopularMenuScreen(),
    );
  }
}

Color pinkColor = const Color(0xFFF0526C);
Color lightPink = const Color(0xFFFCE4E8);
Color grayBg = const Color(0xFFF2F2F2);
Color grayText = const Color(0xFF9B9B9B);
Color badgeColor = const Color(0xFF4A2E22);

class PopularMenuScreen extends StatelessWidget {
  const PopularMenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              topBar(),
              const SizedBox(height: 20),
              searchBar(),
              const SizedBox(height: 20),
              Expanded(
                child: ListView(
                  children: [
                    menuItemWithBadge(
                      color: const Color(0xFFF3A56A),
                      icon: Icons.rice_bowl,
                      title: 'Original Sandwich',
                      subtitle: 'Lovy Food',
                      price: '\$8',
                    ),
                    const SizedBox(height: 16),
                    menuItem(
                      color: const Color(0xFFEDEDED),
                      icon: Icons.eco,
                      title: 'Fresh Salad',
                      subtitle: 'Cloudy Resto',
                      price: '\$10',
                    ),
                    const SizedBox(height: 16),
                    menuItem(
                      color: const Color(0xFFF6D67A),
                      icon: Icons.icecream,
                      title: 'Yummie Ice Cream',
                      subtitle: 'Circlo Resto',
                      price: '\$6',
                    ),
                    const SizedBox(height: 16),
                    menuItem(
                      color: const Color(0xFF6FA06A),
                      icon: Icons.eco,
                      title: 'Vegan Special',
                      subtitle: 'Haty Food',
                      price: '\$11',
                    ),
                    const SizedBox(height: 16),
                    menuItem(
                      color: const Color(0xFFD8D8D8),
                      icon: Icons.ramen_dining,
                      title: 'Mixed Pasta',
                      subtitle: 'Recto Food',
                      price: '\$13',
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.all(16),
        child: bottomBar(),
      ),
    );
  }
}

Widget topBar() {
  return Row(
    children: [
      Container(
        width: 44,
        height: 44,
        decoration: BoxDecoration(
          color: lightPink,
          borderRadius: BorderRadius.circular(14),
        ),
        alignment: Alignment.center,
        child: Icon(Icons.arrow_back_ios_new, color: pinkColor, size: 18),
      ),
      const SizedBox(width: 16),
      const Text(
        'Popular Menu',
        style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
      ),
    ],
  );
}

Widget searchBar() {
  return Row(
    children: [
      Expanded(
        child: Container(
          height: 50,
          padding: const EdgeInsets.symmetric(horizontal: 18),
          decoration: BoxDecoration(
            color: grayBg,
            borderRadius: BorderRadius.circular(25),
          ),
          child: Row(
            children: [
              Text('Search', style: TextStyle(color: grayText, fontSize: 15)),
              const Spacer(),
              Icon(Icons.search, color: grayText),
            ],
          ),
        ),
      ),
      const SizedBox(width: 12),
      Container(
        width: 50,
        height: 50,
        decoration: BoxDecoration(
          color: lightPink,
          borderRadius: BorderRadius.circular(16),
        ),
        alignment: Alignment.center,
        child: Icon(Icons.tune, color: pinkColor),
      ),
    ],
  );
}

Widget menuItem({
  required Color color,
  required IconData icon,
  required String title,
  required String subtitle,
  required String price,
}) {
  return Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(20),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.05),
          blurRadius: 10,
        ),
      ],
    ),
    child: Row(
      children: [
        Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(14),
          ),
          alignment: Alignment.center,
          child: Icon(icon, color: Colors.white),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 4),
              Text(subtitle, style: TextStyle(fontSize: 13, color: grayText)),
            ],
          ),
        ),
        Text(
          price,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: pinkColor),
        ),
      ],
    ),
  );
}

Widget menuItemWithBadge({
  required Color color,
  required IconData icon,
  required String title,
  required String subtitle,
  required String price,
}) {
  return Stack(
    clipBehavior: Clip.none,
    children: [
      menuItem(
        color: color,
        icon: icon,
        title: title,
        subtitle: subtitle,
        price: price,
      ),
      Positioned(
        left: 40,
        top: -10,
        child: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(color: badgeColor, shape: BoxShape.circle),
          alignment: Alignment.center,
          child: const Text('N', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ),
      ),
    ],
  );
}

Widget bottomBar() {
  return Container(
    height: 64,
    padding: const EdgeInsets.symmetric(horizontal: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(32),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.08),
          blurRadius: 12,
        ),
      ],
    ),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
          decoration: BoxDecoration(color: lightPink, borderRadius: BorderRadius.circular(20)),
          child: Row(
            children: [
              Icon(Icons.home, color: pinkColor),
              const SizedBox(width: 6),
              Text('Home', style: TextStyle(color: pinkColor, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        Icon(Icons.shopping_basket, color: pinkColor),
        Icon(Icons.article_outlined, color: pinkColor),
        Icon(Icons.person_outline, color: pinkColor),
      ],
    ),
  );
}
