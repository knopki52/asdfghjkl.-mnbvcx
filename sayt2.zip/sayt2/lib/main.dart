import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: MindDeepRelaxScreen(),
    );
  }
}

const heroColor = Color(0xFFE4A93C);
const pierColor = Color(0xFF394A5A);
const badgeColor = Color(0xFF4A2E22);
const accentColor = Color(0xFF3E8F87);
const grayText = Color(0xFF8A8A8A);

class MindDeepRelaxScreen extends StatelessWidget {
  const MindDeepRelaxScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            hero(),
            const SizedBox(height: 20),
            const Text(
              'Peter Mach',
              style: TextStyle(fontSize: 14, color: grayText),
            ),
            const SizedBox(height: 6),
            const Text(
              'Mind Deep Relax',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800),
            ),
            const SizedBox(height: 10),
            const Text(
              'Join the Community as we prepare over 33 days to relax and feel joy with the mind and happines session across the World.',
              style: TextStyle(fontSize: 14, color: grayText, height: 1.4),
            ),
            const SizedBox(height: 22),
            playButton(),
            const SizedBox(height: 22),
            sessionRow(
              color: const Color(0xFF3E5FCC),
              title: 'Sweet Memories',
              subtitle: 'December 29 Pre-Launch',
            ),
            const Divider(height: 32),
            sessionRow(
              color: accentColor,
              title: 'A Day Dream',
              subtitle: 'December 29 Pre-Launch',
            ),
            const Divider(height: 32),
            sessionRow(
              color: const Color(0xFFE08A2E),
              title: 'Mind Explore',
              subtitle: 'December 29 Pre-Launch',
            ),
          ],
        ),
      ),
    );
  }
}

Widget hero() {
  return Container(
    height: 260,
    decoration: BoxDecoration(
      color: heroColor,
      borderRadius: BorderRadius.circular(24),
    ),
    child: Stack(
      alignment: Alignment.bottomCenter,
      children: [
        const Positioned(
          top: 20,
          left: 24,
          child: Icon(Icons.cloud, size: 28, color: Colors.white54),
        ),
        const Positioned(
          top: 40,
          right: 40,
          child: Icon(Icons.cloud, size: 22, color: Colors.white54),
        ),
        Positioned(
          bottom: 40,
          child: Container(
            width: 160,
            height: 14,
            decoration: BoxDecoration(
              color: pierColor,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
        ),
        const Positioned(
          bottom: 46,
          child: Icon(Icons.accessibility_new, size: 90, color: pierColor),
        ),
        Positioned(
          top: 30,
          child: badge(),
        ),
      ],
    ),
  );
}

Widget badge() {
  return Container(
    width: 30,
    height: 30,
    decoration: const BoxDecoration(
      color: badgeColor,
      shape: BoxShape.circle,
    ),
    alignment: Alignment.center,
    child: const Text(
      'N',
      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
    ),
  );
}

Widget playButton() {
  return Container(
    width: double.infinity,
    height: 54,
    decoration: BoxDecoration(
      color: accentColor,
      borderRadius: BorderRadius.circular(27),
    ),
    child: const Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.play_arrow, color: Colors.white),
        SizedBox(width: 8),
        Text(
          'Play Next Session',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ],
    ),
  );
}

Widget sessionRow({
  required Color color,
  required String title,
  required String subtitle,
}) {
  return Row(
    children: [
      Container(
        width: 48,
        height: 48,
        decoration: BoxDecoration(
          color: color,
          borderRadius: BorderRadius.circular(12),
        ),
        alignment: Alignment.center,
        child: const Icon(Icons.play_arrow, color: Colors.white),
      ),
      const SizedBox(width: 14),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 13, color: grayText),
            ),
          ],
        ),
      ),
      const Icon(Icons.more_horiz, color: grayText),
    ],
  );
}
